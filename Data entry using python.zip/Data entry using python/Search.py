from pathlib import Path
import PySimpleGUI as sg
import pandas as pd

# Add some color to the window
sg.theme('DarkTeal9')

current_dir = Path(__file__).parent if '__file__' in locals() else Path.cwd()
EXCEL_FILE = current_dir / 'Data_Entry.xlsx'

# Load the data if the file exists, if not, create a new DataFrame
if EXCEL_FILE.exists():
    df = pd.read_excel(EXCEL_FILE)
else:
    df = pd.DataFrame()

layout = [
    [sg.Text('Search by Name:', size=(15, 1)), sg.InputText(key='SearchName'), sg.Button('Search')],
    [sg.Text('Please fill out the following fields:', size=(30, 1))],
    [sg.Text('Name', size=(15,1)), sg.InputText(key='Name', size=(30, 1))],
    [sg.Text('School', size=(15,1)), sg.InputText(key='School', size=(30, 1))],
    [sg.Text('Contact Number', size=(15,1)), sg.InputText(key='ContactNumber', size=(30, 1))],
    [sg.Text('Birthdate', size=(15,1)), sg.InputText(key='Birthdate', enable_events=True, size=(30, 1))],
    [sg.Submit(), sg.Button('Clear'), sg.Exit()],
    [sg.Multiline('', size=(60, 10), key='-OUTPUT-')]  # Add this multiline element to display the data
]

window = sg.Window('Simple data entry form', layout, size=(800, 600))

def clear_input():
    for key in values:
        window[key]('')
    return None

def search_data(name):
    return df[df['Name'].str.contains(name, case=False)]

while True:
    event, values = window.read()
    if event == sg.WIN_CLOSED or event == 'Exit':
        break
    if event == 'Clear':
        clear_input()
    if event == 'Submit':
        new_record = pd.DataFrame(values, index=[0])
        df = pd.concat([df, new_record], ignore_index=True)
        df.to_excel(EXCEL_FILE, index=False)  # This will create the file if it doesn't exist
        sg.popup('Data saved!')
        clear_input()
    if event == 'Search':
        search_name = values['SearchName']
        if search_name:
            search_result = search_data(search_name)
            window['-OUTPUT-'].update(search_result.to_string(index=False))
        else:
            window['-OUTPUT-'].update(df.to_string(index=False))
window.close()