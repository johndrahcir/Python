import pandas as pd
import tkinter as tk
from tkinter import messagebox
from tkinter import simpledialog

# Function to read data from specific Excel file
def read_excel_file():
    try:
        filepath = "C:/My Files/CSC FILES/Python/dataset.xlsx"  # Change this to your specific Excel file path
        df = pd.read_excel(filepath)
        messagebox.showinfo("Success", "Excel file loaded successfully!")
        return df
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {e}")
        return None

# Function to save data to Excel file
def save_to_excel(df):
    try:
        filepath = "output_file.xlsx"  # Change this to your desired output Excel file path
        df.to_excel(filepath, index=False)
        messagebox.showinfo("Success", "Data saved to Excel file successfully!")
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {e}")

# Function to handle search functionality
def search_data(root):
    def perform_search():
        search_query = entry_search.get()
        if search_query:
            result_df = data[data.apply(lambda row: search_query.lower() in str(row).lower(), axis=1)]
            if not result_df.empty:
                # Sort the search result DataFrame by Name, Contact No., Birthdate, and Address
                result_df = result_df.sort_values(by=['Name', 'Contact No.', 'Birthdate', 'Address'])
                
                search_result_text.config(state=tk.NORMAL)
                search_result_text.delete('1.0', tk.END)
                search_result_text.insert(tk.END, result_df.to_string(index=False))
                search_result_text.config(state=tk.DISABLED)
            else:
                search_result_text.config(state=tk.NORMAL)
                search_result_text.delete('1.0', tk.END)
                search_result_text.insert(tk.END, "No matching data found.")
                search_result_text.config(state=tk.DISABLED)
        else:
            messagebox.showwarning("Warning", "Please enter a search query.")

    search_window = tk.Toplevel(root)
    search_window.title("Search Data")

    label_search = tk.Label(search_window, text="Enter search query:")
    label_search.pack(pady=5)

    entry_search = tk.Entry(search_window)
    entry_search.pack(pady=5)

    search_button = tk.Button(search_window, text="Search", command=perform_search)
    search_button.pack(pady=5)

    search_result_text = tk.Text(search_window, height=10, width=50, state=tk.DISABLED)
    search_result_text.pack(pady=10)

# Function to handle adding data
def add_data():
    pass  # Implement your add data functionality here

# Function to handle editing data
def edit_data():
    pass  # Implement your edit data functionality here

# Function to handle deleting data
def delete_data():
    pass  # Implement your delete data functionality here

# Function to handle the main menu
def main_menu():
    def save_excel():
        if data is not None:
            save_to_excel(data)
        else:
            messagebox.showwarning("Warning", "No data to save!")

    root = tk.Tk()
    root.title("Data Entry Program")

    # Main menu buttons
    search_button = tk.Button(root, text="Search Data", command=lambda: search_data(root))
    search_button.pack(pady=5)

    add_button = tk.Button(root, text="Add Data", command=add_data)
    add_button.pack(pady=5)

    edit_button = tk.Button(root, text="Edit Data", command=edit_data)
    edit_button.pack(pady=5)

    delete_button = tk.Button(root, text="Delete Data", command=delete_data)
    delete_button.pack(pady=5)

    save_button = tk.Button(root, text="Save to Excel", command=save_excel)
    save_button.pack(pady=5)

    exit_button = tk.Button(root, text="Exit", command=root.quit)
    exit_button.pack(pady=5)

    root.mainloop()

if __name__ == "__main__":
    data = read_excel_file()  # Global variable to hold loaded data
    main_menu()
